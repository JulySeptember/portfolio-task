module portfolio/backend

go 1.25.0

require (
	github.com/aws/aws-lambda-go v1.54.0
	github.com/awslabs/aws-lambda-go-api-proxy v0.16.2
	github.com/go-playground/validator/v10 v10.30.2
	github.com/go-sql-driver/mysql v1.9.3
	github.com/google/uuid v1.6.0
)

require (
	filippo.io/edwards25519 v1.1.0 // indirect
	github.com/gabriel-vasile/mimetype v1.4.13 // indirect
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/leodido/go-urn v1.4.0 // indirect
	golang.org/x/crypto v0.49.0 // indirect
	golang.org/x/sys v0.42.0 // indirect
	golang.org/x/text v0.35.0 // indirect
)
