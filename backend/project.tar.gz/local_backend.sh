local-----------------------------------------------

MySQLのリセット
make db-reset
make run 

make bootstrap-dev

AWS--------------------------------------------------

ユーザー作成

source local_script.txt

curl -X POST $URL/api/v1/auth/bootstrap \
-H "Authorization: Bearer $ID_TOKEN"

ユーザー作成後テスト

source local_script.txt

curl $URL/health

curl -X POST $URL/api/v1/tasks \
-H "Authorization: Bearer $ID_TOKEN" \
-H "Content-Type: application/json" \
-d '{"title":"first task","description":"hello world","status":"TODO","due_date":"2026-06-01T12:00:00Z"}'

curl -X PUT $URL/api/v1/tasks/1 \
-H "Authorization: Bearer $ID_TOKEN" \
-H "Content-Type: application/json" \
-d '{"title":"updated title","description":"updated description","status":"DOING","due_date":"2026-06-10T15:00:00Z"}'

curl -X PATCH $URL/api/v1/tasks/1/status \
-H "Authorization: Bearer $ID_TOKEN" \
-H "Content-Type: application/json" \
-d '{"status":"DONE"}'

curl $URL/api/v1/tasks \
-H "Authorization: Bearer $ID_TOKEN"

curl $URL/api/v1/tasks/1 \
-H "Authorization: Bearer $ID_TOKEN"

curl -X DELETE $URL/api/v1/tasks/1 \
-H "Authorization: Bearer $ID_TOKEN"


source local_script.txt

curl $URL/api/v1/users/me \
-H "Authorization: Bearer $ID_TOKEN"

curl -X DELETE $URL/api/v1/users/me \
-H "Authorization: Bearer $ID_TOKEN"